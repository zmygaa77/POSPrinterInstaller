XPrinter POSPrinter POS-58 driver (INF аргаар суулгах)
=========================================================

Энэ фолдерт INF-based (pnputil) суулгалтад ЗААВАЛ дараах файлууд байх ёстой:

  XPrinter\
    posprtv6.inf          <- ОРСОН (таны өгсөн)
    posprtdrv6.cat         <- ОРСОН (таны өгсөн)
    amd64\
      posprtdrv6.dll        <- ДУТУУ, нэмж хийх ёстой
      posprtdrv6ui.dll      <- ДУТУУ, нэмж хийх ёстой
    dat\
      posprtdrv6.dat        <- ДУТУУ, нэмж хийх ёстой

posprtv6.inf файлын [SourceDisksFiles] хэсэгт яг эдгээр 3 файлыг
яг эдгээр дэд фолдеруудаас (amd64\, dat\) хайхаар заасан байгаа тул,
эдгээргүйгээр "pnputil /add-driver" алдаатай гарна
(жишээ нь "The specified INF is not a valid driver package"
эсвэл "0x800f0247" гэх мэт алдаа өгч болно).

Эдгээр 3 файлыг хаанаас олох вэ:
  1. drvinst.exe (эсвэл Xprinter-ийн эх суулгагч) файлыг 7-Zip-ээр
     нээж ("Open archive" эсвэл right-click > 7-Zip > Open archive")
     дотор нь яг ижил нэртэй dll/dat файлуудыг хайж олоод хуулна.
  2. Хэрэв тухайн компьютер дээр өмнө нь drvinst.exe-г ажиллуулж
     driver-ийг wizard-аар нэг удаа суулгасан бол:
       C:\Windows\System32\DriverStore\FileRepository\posprtv6.inf_xxxxxxxx\
     фолдерт эдгээр dll/dat файлууд аль хэдийн байгаа байх магадлалтай
     (fолдерийн нэрийн ард санамсаргүй тэмдэгт залгагдсан байдаг).
  3. Эсвэл үйлдвэрлэгчээс (эсвэл таны drvinst.exe-г танд өгсөн эх
     сурвалжаас) шууд "driver package (INF хэлбэр)" гэж асууж авах.

Гурвыг нь оруулж дуусангуутаа "installMethod": "inf" тохиргоо бүхий
printers.json бичлэг шууд ажиллах болно.
