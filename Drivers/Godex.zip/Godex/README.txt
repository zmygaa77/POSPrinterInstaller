Энэ фолдерт Godex принтерийн driver суулгагч файлыг байршуулна уу.
Файлын нэр Database/printers.json дахь "driverInstallerPath" утгатай таарч байх ёстой.
