Энэ фолдерт SPRT POS58 принтерийн driver суулгагч (driver.exe эсвэл .msi) файлыг
байршуулна уу. Файлын нэр Database/printers.json дахь "driverInstallerPath"
утгатай яг таарч байх ёстой (жишээ нь: SPRT_POS58\driver.exe).
