[CatalogHeader]
Name=SWLabel.cat
ResultDir=.
PublicVersion=0x0000001
CatalogVersion=2
HashAlgorithms=SHA256
PageHashes=false
EncodingType=

[CatalogFiles]
<hash>SWLabel.INF=SWLabel.INF
<hash>SWLabel.GPD=SWLabel.GPD
<hash>SWLabel.INI=SWLabel.INI
<hash>SWLabel.DLL=SWLabel.DLL
<hash>SWLabelUI.DLL=SWLabelUI.DLL
<hash>SWLabelUNI.DLL=SWLabelUNI.DLL