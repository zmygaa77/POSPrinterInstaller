[CatalogHeader]
Name=SLK-Txxx.cat
ResultDir=.
PublicVersion=0x0000001
CatalogVersion=2
HashAlgorithms=SHA256
PageHashes=false
EncodingType=

[CatalogFiles]
<hash>SLK-Txxx.INF=SLK-Txxx.INF
<hash>LKNEW4.Dll=LKNEW4.Dll
<hash>LKNEW4.GPD=LKNEW4.GPD
<hash>LKNEW4.ini=LKNEW4.ini
<hash>LKNEW4E.dll=LKNEW4E.dll
<hash>LKNEW4UI.dll=LKNEW4UI.dll