Энэ фолдерт Sewoo LK-B20 принтерийн driver суулгагч файлыг байршуулна уу.
Файлын нэр Database/printers.json дахь "driverInstallerPath" утгатай таарч байх ёстой.
